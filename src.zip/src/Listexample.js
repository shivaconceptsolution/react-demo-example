
import React , { Component}  from 'react';


function Listexample(props)
{
    var course = props.course;
    var d = course.map((data) => {
        return <li>{data}</li>;
    });
    return(
        <div>
        <ul>{d}</ul>
        </div>
    );
}

export default Listexample;