import React, { useState } from "react";

export class Swap extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {a:'',b:''}
        this.handleInput = this.handleInput.bind(this);
        this.handleInput1 = this.handleInput.bind(this);
        this.handleClick = this.handleClick.bind(this);

    }
   
    handleInput(e)
    {
       
        this.setState({a:e.target.value});
    }
    handleInput1(e)
    {
        this.setState({b:e.target.value});
        
    }
    handleClick(e)
    {
     let temp = this.state.a;
     this.setState({'a':this.state.b});
     this.setState({'b':this.state.temp});
    

     
        
    }
   render()
   {
    return(
     <div>
      <input type="text" onChange={this.handleInput}  /> 
      <br />
      <input type="text" onChange={this.handleInput1}/> 
      <br />
      <input type="button" onClick={this.handleClick} value="Swap" /> 
      <p>a={this.state.a},b={this.state.b}</p>
     </div>

    )
   }
}

