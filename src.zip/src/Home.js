import React   from 'react';

function Home()
{
  
   
  
    return(
        <div id="middle">
           
            <p>Welcome in home page</p>
        </div>
    );
}

export default Home;