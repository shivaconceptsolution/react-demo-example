import React   from 'react';

function About()
{
  
 
  
    return(
        <div id="middle">
             
            <p>Welcome in About us page</p>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/rrihULaufro" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    );
}

export default About;