import React from "react";
export class Uncontrolled extends React.Component
{
    constructor(props)
    {
        super(props);
        this.fun = this.fun.bind(this);
        this.input = React.createRef();
    }

    fun(event)
    {
       // alert(this.input.current.value);
       var num=parseInt(this.input.current.value);
    var s = "";

    for(var i=2;i<num;i++)
    {
        if(num%i==0)
        {
            s = "Not Prime";
            break;
        }
    }
    if(num==i)
    {
        s = "Prime";
    }
    alert(s);
        event.preventDefault();
    }
    render()
    {
        return(
            <form onSubmit={this.fun}>
                 <input type="text" placeholder="Enter first number" ref={this.input} />
                 <br></br>
                 <input type="submit" value="Click" />
            </form>
        );
    }

}