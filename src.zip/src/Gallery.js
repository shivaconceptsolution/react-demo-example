import React   from 'react';

function Home()
{
  
   
  
    return(
        <div id="middle">
           
            
            <p>Welcome in Gallery page</p>
            <div className="ga">
                <img src="1.jpg"  />
            </div>
            <div className="ga">
                <img src="2.jpg"  />
            </div>
            <div className="ga">
                <img src="3.jpg"  />
            </div>
            <div className="ga">
                <img src="4.jpg"  />
            </div>
            <div className="ga">
                <img src="4.jpg"  />
            </div>
            <div className="ga">
                <img src="4.jpg"  />
            </div>
        </div>
    );
}

export default Home;