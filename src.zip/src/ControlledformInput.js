import React from "react";
export class ControllerformInput extends React.Component
{
  
    constructor(props)
    {
       
        super(props);
        
        this.state = {exp:'',c:''};
       
        this.updateSubmit = this.updateSubmit.bind(this);
        this.calc = this.calc.bind(this);
    }
    
    
     updateSubmit(event)
     {
     
        this.setState({exp:this.state.exp.concat(event.target.value)})
      
      
         event.preventDefault();
     }
     calc(event)
     {
        var s=this.state.exp;
      /*  var t=0;
        for(var i=0;i<s.length;i++)
        {
         
         if(s[i]=='+')
         {
            if(i==1)
            { 
            t = t+ parseInt(s[i-1]) + parseInt(s[i+1]);
            }
            else
            {
                t = t+parseInt(s[i+1]);
            }
           
         }
         else if(s[i]=='-')
         {
             if(i==1)
            { 
            t = t+ parseInt(s[i-1]) - parseInt(s[i+1]);
            }
            else
            {
            t = t-parseInt(s[i+1]);
            }
            
         }
         else if(s[i]=='*')
         {
             if(i==1)
            { 
            t = t+ parseInt(s[i-1]) * parseInt(s[i+1]);
            }
            else
            {
            t = t*parseInt(s[i+1]);
            }
           
         }
         else if(s[i]=='/')
         {
             if(i==1)
            { 
            t = t+ parseInt(s[i-1]) / parseInt(s[i+1]);
            }
            else
            {
            t = t/parseInt(s[i+1]);
            }
         }

         
     }*/
    // this.setState({'c':t});
     this.setState({'c':eval(s)});
     event.preventDefault();
    }
    render()
    {
      
        return(
            <div>
                <form >
                    <input type="text"  value={this.state.exp}  />
                    <br/>
                  
                    <br/>
                    <input type="submit" name="btnsubmit" value="1" onClick={this.updateSubmit}/>
                    <input type="submit" name="btnsubmit" value="2" onClick={this.updateSubmit}/>
                     <input type="submit" name="btnsubmit" value="+" onClick={this.updateSubmit}/>
                     <input type="submit" name="btnsubmit" value="-" onClick={this.updateSubmit}/>
                     <input type="submit" name="btnsubmit" value="=" onClick={this.calc}/>
                </form>
                <div>{this.state.c}</div>
            </div>
        );
    }
}