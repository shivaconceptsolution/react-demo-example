function SI(props)
{
   var p = props.res.p;
   var r = props.res.r;
   var t = props.res.t;
   var si = (p*r*t)/100;
    return(
    <div>
      {si}
    </div>)

}
export default SI;