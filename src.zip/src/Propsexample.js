function Propsexample(props)
{
    var a1 = props.c.a1;
    var b1 = props.c.b1;
    var c1 = a1+b1;
    return(
     <div>
      {props.scs}
      <br/>
      {props.a}
      <br/>
      {props.b}
      <br/>
      {c1}
     </div>
    )
}

export default Propsexample;