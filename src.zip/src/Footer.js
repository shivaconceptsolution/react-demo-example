import React   from 'react';

function Footer()
{
  
   
  
    return(
        <div id="footer">
           
            <center>&copy;2022 by scs</center>
        </div>
    );
}

export default Footer;