function RectLogic(props)
{
    var a = props.w;
    var b = props.h;
    var area = a*b;
    return (
        <div>{area}</div>
    );
}

export default RectLogic;