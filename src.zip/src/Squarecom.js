import React, { useState } from "react";

export class Squarecom extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={'a':'','res':''};
        this.setNumber = this.setNumber.bind(this);
        this.calculate = this.calculate.bind(this);
    }

   setNumber(e)
{
   // alert(e.target.value);
     this.setState({'a':e.target.value});

}
 calculate(e)
{
    this.setState({'res':(parseInt(this.state.a)*parseInt(this.state.a))});

   // alert(a);
    e.preventDefault();
}
render()
{
    return(
    <div>
            <form onSubmit={this.calculate}>
            <input type="text" onChange={this.setNumber}  />
            <br />
            <input type="submit" value="click" />
            </form>
        <p>{this.state.res}</p>
    </div>
); 
}



}

