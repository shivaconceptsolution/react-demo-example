import  { useRef } from "react";
function Add()
{
    const num1 = useRef()
    const num2 = useRef()
   function addition(event)
    {
        var c = parseInt(num1.current.value) + parseInt(num2.current.value);
        alert(c);
        event.preventDefault();
       

    }
   
        return(
            <form onSubmit={addition} >
            <input type="text" ref={num1} placeholder="Enter first number" />
            <br></br>
            <input type="text" ref={num2} placeholder="Enter Second number" />
            <br></br>
            <input type="submit" name="btnsu" value="Addition" />
            </form>
        );
   

}

export default Add;