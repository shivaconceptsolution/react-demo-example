function Calc()
{
   var s="8-5*3*6+5";
   var t=0;
   for(var i=0;i<s.length;i++)
   {
    
    if(s[i]=='+')
    {
       if(i==1)
       { 
       t = t+ parseInt(s[i-1]) + parseInt(s[i+1]);
       }
       else
       {
           t = t+parseInt(s[i+1]);
       }
      
    }
    else if(s[i]=='-')
    {
        if(i==1)
       { 
       t = t+ parseInt(s[i-1]) - parseInt(s[i+1]);
       }
       else
       {
       t = t-parseInt(s[i+1]);
       }
       
    }
    else if(s[i]=='*')
    {
        if(i==1)
       { 
       t = t+ parseInt(s[i-1]) * parseInt(s[i+1]);
       }
       else
       {
       t = t*parseInt(s[i+1]);
       }
      
    }
    else if(s[i]=='/')
    {
        if(i==1)
       { 
       t = t+ parseInt(s[i-1]) / parseInt(s[i+1]);
       }
       else
       {
       t = t/parseInt(s[i+1]);
       }
    }

   }

     return(
         
        <div>
         <p>{t}</p>
        </div>

    )

}

export default Calc;