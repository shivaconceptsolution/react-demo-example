import React   from 'react';
function ListExampleNew()
{
  
    var a = [2500,5000,1200,3500];
    var max = 0;
    for(var i=0;i<a.length;i++)
    {
        if(max<a[i])
        {
            max=a[i];
        }
    }
  
    return(
        <div>
           
            <p>Max is :- {max}</p>
        </div>
    );
}

export default ListExampleNew;