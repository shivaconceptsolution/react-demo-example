import { useState } from "react";

function Reactarea()
{
    let [w,setW] = useState(0);
    let [l,setL] = useState(0);
    let [a,setA] = useState(0);
    function setWidth(e)
    {
        setW(e.target.value);
    }
    function setLength(e)
    {
        setL(e.target.value);
    }
    function rarea(e)
    {
        setA(w*l);
        e.preventDefault();
    }
    return(
        <div>
         <form onSubmit={rarea}>
             <input type="text" onChange={(e) => setWidth(e)} />
             <br/>
             <input type="text" onChange={(e) => setLength(e)} />
             <br/>
             <input type="submit" value="Calculate" /> 

         </form>
          <p>{a}</p>
        </div>

    );

}

export default Reactarea;