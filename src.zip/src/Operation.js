function Operation()
{
    return (
        <div>
           <Add />
           <Sub />
           <Multi /> 
           <Division /> 
        </div>

    );
}




function Add()
{
    var a=100;
    var b=200;
    return (
        <div>
           <p>Result is {a+b}</p>    
        </div>

    );
}

function Sub()
{
    var a=100;
    var b=200;
    return (
        <div>
           <p>Result is {a-b}</p>    
        </div>

    );
}

function Multi()
{
    var a=100;
    var b=200;
    return (
        <div>
           <p>Result is {a*b}</p>    
        </div>

    );
}


function Division()
{
    var a=100;
    var b=200;
    return (
        <div>
           <p>Result is {a/b}</p>    
        </div>

    );
}

export default Operation;