import React   from 'react';
import { Link } from "react-router-dom";
function Header()
{
  
   
  
    return(
        <div id="header">
           <div className="logopart">
               <img src="logo192.png" style={{width:"50px",height:"50px"}} />
           </div>
           <div className="navpart">
           <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About us</Link>
          </li>
          <li>
            <Link to="/services">Services</Link>
          </li>
          <li>
            <Link to="/gallery">Gallery</Link>
          </li>
          <li>
            <Link to="/contact">Contact us</Link>
          </li>
        </ul>
           </div>
         
        </div>
    );
}

export default Header;