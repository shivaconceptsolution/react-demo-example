import { useState } from "react";
function increment(n)
{
    return n+1;
}
function ControlledFunctionComponentExample()
{

    const [a,setA] = useState(1);
   
    return(
     <div>
      <input type="button" onClick={() => setA(increment)} value="click" /> 
     
      <p>{a}</p>
     </div>

    )
}

export default ControlledFunctionComponentExample;