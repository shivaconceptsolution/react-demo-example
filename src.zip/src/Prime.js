import { useState } from "react";


function Prime()
{
   const [a,setA] = useState(0);
   const[res,setRes] = useState(""); 
   function fun(e)
   {
       setA(e.target.value);
   }
   function submitPrime(e)
   {
    var num=parseInt(a);
    var s = "";

    for(var i=2;i<num;i++)
    {
        if(num%i==0)
        {
            s = "Not Prime";
            break;
        }
    }
    if(num==i)
    {
        s = "Prime";
    }
    setRes(s);
    e.preventDefault();
   }
    return (
        <div>
            <form onSubmit={(e) => submitPrime(e)}>
            <input type="text" onChange={(e) => fun(e)} />
            <br />
            <input type="submit"  value="Check Prime"/>
           <p>Result is {res}</p>   
           </form> 
        </div>

    );
}

export default Prime;