import React from "react";
export class RadioExample extends React.Component
{
  
    constructor(props)
    {
       
        super(props);
        
        this.state = {a:'',b:'',c:'',o:''};
       
        this.updateSubmit = this.updateSubmit.bind(this);
        this.updateSubmit1 = this.updateSubmit1.bind(this);
        this.radioClick = this.radioClick.bind(this);
        this.calc = this.calc.bind(this);
    }
    
    
     updateSubmit(event)
     {
     
        this.setState({a:event.target.value})
        event.preventDefault();
     }
     updateSubmit1(event)
     {
     
        this.setState({b:event.target.value})
        event.preventDefault();
     }
     radioClick(event)
     {
     
        this.setState({o:event.target.value})
        //event.preventDefault();
     }
     calc(event)
     {
     if(this.state.o == "+")
     {
        this.setState({'c':parseInt(this.state.a)+parseInt(this.state.b)});
     }   
     else
     {
        this.setState({'c':parseInt(this.state.a)-parseInt(this.state.b)});
     }
     event.preventDefault();
    }
    render()
    {
      
        return(
            <div>
                <form>
                    <input type="radio" name="ope" value="+" onChange={this.radioClick}   />+
                    <input type="radio" name="ope" value="-" onChange={this.radioClick}  />-
                    <br></br>
                    <input type="text"  value={this.state.exp} placeholder="Enter First Number" onChange={this.updateSubmit}  />
                    <br/>
                    <input type="text"  value={this.state.exp} placeholder="Enter Second Number" onChange={this.updateSubmit1} />
                    <br/>
                    <input type="submit" name="btnsubmit" value="Calculate" onClick={this.calc}/>
                </form>
                <div>{this.state.c}</div>
            </div>
        );
    }
}