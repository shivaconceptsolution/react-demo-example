import React   from 'react';
import Home from './Home';
import About from './About';
import Master from './Master';
import Services from './Services'
import Gallery from './Gallery'
import Contact from './Contact'
import { BrowserRouter, Routes, Route } from "react-router-dom";
function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Master />}>
       
        <Route index  element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="services" element={<Services />} />
        <Route path="gallery" element={<Gallery />} />
        <Route path="contact" element={<Contact />} />
        </Route>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
