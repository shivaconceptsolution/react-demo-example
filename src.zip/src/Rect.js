import RectLogic from "./RectLogic";

function Rect()
{
    var w = 1000;
    var h = 2;
    return(

        <div>
         <RectLogic w = {w} h = {h} />
        </div>
    );
}

    
export default Rect;