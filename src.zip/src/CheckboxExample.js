import React from "react";
export class CheckboxExample extends React.Component
{
  
    constructor(props)
    {
       
        super(props);
        
        this.state = {c1:'',c2:'',c:'',l:''};
        this.ddl = this.ddl.bind(this);
        this.lst = this.lst.bind(this);
        this.calc = this.calc.bind(this);
      
    }
    
    
     
     calc(event)
     {
  
     this.setState({c:this.state.c1+ " "+this.state.l});
     event.preventDefault();
    }
    ddl(event)
    {
      
        this.setState({c1:event.target.value})
       
    }
    lst(event)
    {
        var s = "";
       // alert(event.target.options[0].selected);
        for(var i=0;i<event.target.length;i++)
        {
            if(event.target.options[i].selected)
            {
                s = s + event.target.options[i].value;
            }
        }
        this.setState({l:s})
       
    }
    render()
    {
      
        return(
            <div>
                <form>
                    <select onChange={this.ddl}>
                        <option value="C:1000">C</option>
                        <option value="CPP:2000">CPP</option>
                        <option value="DS:3000">DS</option>
                    </select>
                    <br/>
                    <br/>
                    <select onChange={this.lst} multiple>
                        <option value="C:1000">C</option>
                        <option value="CPP:2000">CPP</option>
                        <option value="DS:3000">DS</option>
                    </select>
                    <br></br>
                  
                    <br></br>
                   
                    <input type="submit" name="btnsubmit" value="Calculate" onClick={this.calc}/>
                </form>
                <div>Courses are {this.state.c} </div>
            </div>
        );
    }
}